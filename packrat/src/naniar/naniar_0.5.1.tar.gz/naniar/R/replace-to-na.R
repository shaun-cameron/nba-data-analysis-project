#' Replace values with missings
#'
#' This function is Defunct, please see [replace_with_na()].
#'
#' @param ... additional arguments for methods.
#'
#' @return values replaced by NA
#' @export
#'
replace_to_na <- function(...){
  .Defunct("replace_with_na")
}
